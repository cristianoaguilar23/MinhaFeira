# Minha Feira — versão 1.2

Aplicativo Android pessoal de lista de compras, com dados armazenados localmente.

## Recursos no código-fonte
- Tela de abertura com “Desenvolvido por Cristiano Aguilar”.
- Uso offline: o manifesto não declara a permissão `INTERNET` e a impressão bloqueia carregamentos de rede no WebView.
- Criar e manter várias listas.
- Produtos com numeração automática, descrição, quantidade, valor unitário e total calculado.
- Total geral da lista.
- Editar e excluir produtos, com confirmação antes da exclusão.
- Duplicar uma lista para o mês seguinte; os itens duplicados começam desmarcados.
- Histórico de listas armazenado no aparelho.
- Modo carrinho com marcação dos produtos comprados.
- Resumo financeiro do valor já colocado no carrinho e do que falta comprar.
- Impressão pelo serviço nativo do Android, com opção de salvar como PDF.

## Gerar o APK
1. Em um computador, instale o Android Studio.
2. Abra a pasta `MinhaFeira` (não o arquivo ZIP) no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitada. A primeira preparação do ambiente exige internet para baixar ferramentas e bibliotecas; depois de compilado, o aplicativo funciona sem internet.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Estado desta entrega
Este pacote contém o projeto-fonte atualizado. Não contém um APK compilado: o ambiente em que o projeto foi preparado não possui Android SDK nem Gradle instalado, portanto não foi possível compilar nem testar em aparelho real nesta etapa.

Os dados são guardados no armazenamento privado do aplicativo. Antes de desinstalar o app ou trocar de aparelho, faça backup do dispositivo, pois a desinstalação pode apagar os dados locais.

## Gerar o APK sem computador (compilação na nuvem)

Este projeto inclui o workflow `.github/workflows/gerar-apk.yml` para compilar o APK nos servidores do GitHub Actions. Isso evita instalar Android Studio no celular, mas exige uma conta GitHub e enviar os arquivos do projeto para um repositório.

1. No navegador do celular, entre em `https://github.com` e crie uma conta ou entre na sua.
2. Crie um repositório novo chamado `MinhaFeira`.
3. Extraia o ZIP do projeto e envie os arquivos e pastas para a raiz do repositório (não envie a pasta externa que apenas contém o projeto; envie o conteúdo da pasta `MinhaFeira`). É necessário incluir a pasta oculta `.github`.
4. No repositório, abra **Actions** e selecione **Gerar APK Minha Feira**.
5. Toque em **Run workflow** e confirme em **Run workflow**.
6. Quando a execução terminar com sucesso, abra a execução e baixe o artefato **Minha-Feira-APK**. Dentro do ZIP baixado estará `app-debug.apk`.
7. Abra o APK no Android e autorize a instalação dessa fonte, se o sistema solicitar.

A compilação na nuvem requer internet e conta GitHub. Depois de instalado, o aplicativo foi projetado para funcionar offline. O APK gerado por esse fluxo é de depuração (debug), adequado para instalação e teste pessoal; ainda deve ser testado no aparelho antes de ser considerado uma versão final.
