package com.cristiano.minhafeira

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF16865B)
private val DarkGreen = Color(0xFF0D6845)
private val Pale = Color(0xFFF2F8F4)
private val Ink = Color(0xFF20342B)
private val Muted = Color(0xFF718078)
private val money = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
private val ptMonths = listOf(
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
)

data class Product(val description: String, val quantity: Double, val unitPrice: Double, val purchased: Boolean = false) {
    val total: Double get() = quantity * unitPrice
}

data class ShoppingList(val name: String, val products: List<Product>) {
    val total: Double get() = products.sumOf { it.total }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = DarkGreen, background = Pale)) {
                FeiraApp(this)
            }
        }
    }
}

private fun loadLists(context: Context): MutableList<ShoppingList> {
    val raw = context.getSharedPreferences("feira", Context.MODE_PRIVATE)
        .getString("lists", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        MutableList(array.length()) { index ->
            val obj = array.getJSONObject(index)
            val productsJson = obj.getJSONArray("products")
            ShoppingList(
                obj.getString("name"),
                List(productsJson.length()) { productIndex ->
                    val item = productsJson.getJSONObject(productIndex)
                    Product(
                        item.getString("description"),
                        item.getDouble("quantity"),
                        item.getDouble("unitPrice"),
                        item.optBoolean("purchased", false)
                    )
                }
            )
        }
    } catch (_: Exception) {
        mutableListOf()
    }
}

private fun saveLists(context: Context, lists: List<ShoppingList>) {
    val array = JSONArray()
    lists.forEach { list ->
        val products = JSONArray()
        list.products.forEach { product ->
            products.put(
                JSONObject()
                    .put("description", product.description)
                    .put("quantity", product.quantity)
                    .put("unitPrice", product.unitPrice)
                    .put("purchased", product.purchased)
            )
        }
        array.put(JSONObject().put("name", list.name).put("products", products))
    }
    context.getSharedPreferences("feira", Context.MODE_PRIVATE)
        .edit().putString("lists", array.toString()).apply()
}

private fun currentMonthListName(): String {
    val calendar = Calendar.getInstance()
    return "Feira - ${ptMonths[calendar.get(Calendar.MONTH)].replaceFirstChar { it.uppercase() }} ${calendar.get(Calendar.YEAR)}"
}

/** Cria uma cópia com o mês avançado, preservando os produtos e valores. */
private fun duplicateForNextMonth(source: ShoppingList): ShoppingList {
    val monthPattern = Regex("(${ptMonths.joinToString("|")})\\s+(\\d{4})", RegexOption.IGNORE_CASE)
    val match = monthPattern.find(source.name)
    val calendar = Calendar.getInstance()
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val prefix: String
    if (match != null) {
        val monthIndex = ptMonths.indexOf(match.groupValues[1].lowercase(Locale("pt", "BR")))
        val year = match.groupValues[2].toIntOrNull() ?: calendar.get(Calendar.YEAR)
        if (monthIndex >= 0) {
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, monthIndex)
        }
        prefix = source.name.substring(0, match.range.first).trim().trimEnd('-', '–').trim().ifBlank { "Feira" }
    } else {
        prefix = source.name.trim().ifBlank { "Feira" }
    }
    calendar.add(Calendar.MONTH, 1)
    val monthName = ptMonths[calendar.get(Calendar.MONTH)].replaceFirstChar { it.uppercase() }
    return ShoppingList("$prefix - $monthName ${calendar.get(Calendar.YEAR)}", source.products.map { it.copy(purchased = false) })
}

private fun formatQuantity(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString()
    else String.format(Locale("pt", "BR"), "%.2f", value).trimEnd('0').trimEnd(',')

private fun htmlEscape(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&#39;")

/** Abre a tela nativa de impressão do Android. Nela é possível imprimir ou salvar como PDF. */
private fun printShoppingList(context: Context, list: ShoppingList) {
    val activity = context as? Activity ?: return
    val webView = WebView(activity)
    webView.settings.javaScriptEnabled = false
    webView.settings.blockNetworkLoads = true
    webView.settings.allowFileAccess = false
    webView.settings.allowContentAccess = false

    val rows = list.products.mapIndexed { index, product ->
        """
        <tr>
          <td class="center">${if (product.purchased) "✓" else "□"}</td>
          <td class="center">${index + 1}</td>
          <td>${htmlEscape(product.description)}</td>
          <td class="right">${formatQuantity(product.quantity)}</td>
          <td class="right">${money.format(product.unitPrice)}</td>
          <td class="right">${money.format(product.total)}</td>
        </tr>
        """.trimIndent()
    }.joinToString("\n")

    val html = """
        <!doctype html>
        <html lang="pt-br">
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <style>
            @page { size: A4; margin: 16mm; }
            body { font-family: Arial, sans-serif; color: #20342b; font-size: 12px; }
            h1 { color: #16865b; font-size: 23px; margin: 0 0 4px; }
            .subtitle { color: #66756d; margin-bottom: 22px; }
            .author { color: #66756d; font-size: 10px; margin-top: 26px; }
            table { width: 100%; border-collapse: collapse; }
            th { background: #e5f2e9; color: #20342b; text-align: left; }
            th, td { border-bottom: 1px solid #dce6df; padding: 9px 7px; }
            .center { text-align: center; width: 35px; }
            .right { text-align: right; white-space: nowrap; }
            tfoot td { border-top: 2px solid #16865b; border-bottom: 0; font-weight: bold; font-size: 14px; padding-top: 14px; }
            .total-label { text-align: right; }
          </style>
        </head>
        <body>
          <h1>${htmlEscape(list.name)}</h1>
          <div class="subtitle">Lista de compras • ${SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date())}</div>
          <table>
            <thead><tr><th class="center">OK</th><th class="center">Nº</th><th>Descrição</th><th class="right">Qtd.</th><th class="right">Valor unit.</th><th class="right">Total</th></tr></thead>
            <tbody>$rows</tbody>
            <tfoot><tr><td colspan="5" class="total-label">TOTAL DA LISTA</td><td class="right">${money.format(list.total)}</td></tr></tfoot>
          </table>
          <div class="author">Desenvolvido por Cristiano Aguilar</div>
        </body>
        </html>
    """.trimIndent()

    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            if (view == null) return
            val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = view.createPrintDocumentAdapter(list.name)
            val attributes = PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build()
            printManager.print(list.name, adapter, attributes)
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}


@Composable
private fun PriceCell(value: Double, modifier: Modifier = Modifier, onValue: (Double) -> Unit) {
    // O teclado funciona como caixa registradora: cada dígito entra nas casas dos centavos.
    var digits by remember { mutableStateOf((kotlin.math.round(value * 100).toLong()).toString().takeIf { value > 0.0 } ?: "") }
    val shown = if (digits.isBlank()) "0,00" else {
        val cents = digits.toLongOrNull() ?: 0L
        String.format(Locale("pt", "BR"), "%,d,%02d", cents / 100, cents % 100)
            .replace(".", "#").replace(",", ".").replace("#", ",")
    }
    BasicTextField(
        value = shown,
        onValueChange = { typed ->
            val next = typed.filter { it.isDigit() }.trimStart('0')
            digits = next
            onValue((next.toLongOrNull() ?: 0L) / 100.0)
        },
        modifier = modifier.padding(horizontal = 2.dp, vertical = 8.dp),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        textStyle = MaterialTheme.typography.bodySmall.copy(color = Ink),
        decorationBox = { inner ->
            Box {
                if (digits.isBlank()) Text("0,00", color = Muted, style = MaterialTheme.typography.bodySmall)
                inner()
            }
        }
    )
}

@Composable
fun FeiraApp(context: Context) {
    val lists = remember { mutableStateListOf<ShoppingList>().apply { addAll(loadLists(context)) } }
    var current by remember { mutableIntStateOf(-1) }
    var showSplash by remember { mutableStateOf(true) }
    var showEditor by remember { mutableStateOf(false) }
    var editIndex by remember { mutableIntStateOf(-1) }
    var deleteIndex by remember { mutableIntStateOf(-1) }
    var deleteProductIndex by remember { mutableIntStateOf(-1) }

    fun persist() = saveLists(context, lists)

    if (showSplash) {
        Column(
            Modifier.fillMaxSize().background(Pale).windowInsetsPadding(WindowInsets.safeDrawing).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.minha_feira_logo),
                contentDescription = "Logo Minha Feira",
                modifier = Modifier.fillMaxWidth().height(250.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(12.dp))
            Spacer(Modifier.height(8.dp))
            Text("Suas compras organizadas, sem complicação.", color = Muted)
            Spacer(Modifier.height(28.dp))
            Text("Desenvolvido por", color = Muted)
            Text("CRISTIANO AGUILAR", color = Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(34.dp))
            Button(onClick = { showSplash = false }, modifier = Modifier.fillMaxWidth()) { Text("Entrar") }
            Spacer(Modifier.height(12.dp))
            Text("Funciona offline • Dados salvos neste aparelho", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        return
    }

    if (current < 0) {
        Column(Modifier.fillMaxSize().background(Pale).windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 18.dp, vertical = 16.dp)) {
            Text("Olá! Vamos às compras?", style = MaterialTheme.typography.headlineSmall, color = Ink, fontWeight = FontWeight.Bold)
            Text("Tudo salvo no seu celular. Não precisa de internet.", color = Muted)
            Spacer(Modifier.height(18.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2E8)),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                    lists.add(ShoppingList(currentMonthListName(), emptyList()))
                    current = lists.lastIndex
                    persist()
                }
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color.White.copy(alpha = 0.8f), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null, tint = Green, modifier = Modifier.padding(10.dp).size(30.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Nova lista", fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.titleLarge)
                        Text("Comece uma lista de compras", color = Color.DarkGray)
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, null, tint = Green)
                Spacer(Modifier.width(8.dp))
                Text("Minhas listas e histórico", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.weight(1f))
                Text("${lists.size}", color = Green, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))

            if (lists.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CalendarMonth, null, tint = Green, modifier = Modifier.size(38.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Seu histórico aparecerá aqui", color = Ink, fontWeight = FontWeight.SemiBold)
                        Text("Crie sua primeira lista para começar.", color = Muted)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(lists) { index, list ->
                        Card(
                            shape = RoundedCornerShape(17.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            modifier = Modifier.fillMaxWidth().clickable { current = index }
                        ) {
                            Row(Modifier.padding(start = 15.dp, end = 7.dp, top = 13.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(color = Color(0xFFE8F4EC), shape = RoundedCornerShape(12.dp)) {
                                    Icon(Icons.Default.ShoppingCart, null, tint = Green, modifier = Modifier.padding(10.dp).size(23.dp))
                                }
                                Spacer(Modifier.width(11.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(list.name, fontWeight = FontWeight.SemiBold, color = Ink)
                                    Spacer(Modifier.height(3.dp))
                                    Text("${list.products.size} produtos  •  ${money.format(list.total)}", color = Muted, style = MaterialTheme.typography.bodySmall)
                                    Text("Toque para abrir", color = Green, style = MaterialTheme.typography.labelSmall)
                                }
                                IconButton(onClick = {
                                    lists.add(duplicateForNextMonth(list))
                                    persist()
                                }) { Icon(Icons.Default.ContentCopy, "Duplicar para o próximo mês", tint = Green) }
                                IconButton(onClick = { deleteIndex = index }) {
                                    Icon(Icons.Default.Delete, "Excluir lista", tint = Color(0xFFB64B4B))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (deleteIndex >= 0 && deleteIndex < lists.size) {
            AlertDialog(
                onDismissRequest = { deleteIndex = -1 },
                title = { Text("Excluir lista?") },
                text = { Text("A lista '${lists[deleteIndex].name}' será removida deste aparelho.") },
                confirmButton = {
                    TextButton(onClick = {
                        lists.removeAt(deleteIndex)
                        persist()
                        deleteIndex = -1
                    }) { Text("Excluir", color = Color(0xFFB64B4B)) }
                },
                dismissButton = { TextButton(onClick = { deleteIndex = -1 }) { Text("Cancelar") } }
            )
        }
    } else if (current < lists.size) {
        val list = lists[current]
        Column(
            Modifier.fillMaxSize().background(Color(0xFFF7F7F7))
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
            // Cabeçalho respeita a área segura da câmera/status bar.
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { current = -1; showEditor = false }) {
                    Icon(Icons.Default.ArrowBack, "Voltar")
                }
                Column(Modifier.weight(1f)) {
                    Text(list.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink, maxLines = 2)
                    Text("${list.products.size} produtos", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { printShoppingList(context, list) }) {
                    Icon(Icons.Default.Print, "Imprimir ou salvar PDF", tint = Green)
                }
            }

            // Botão de inclusão fica no topo, longe da navegação inferior do Android.
            Button(
                onClick = { editIndex = -1; showEditor = true },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                contentPadding = PaddingValues(8.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(7.dp))
                Text("Adicionar produto")
            }
            Spacer(Modifier.height(8.dp))

            val boughtCount = list.products.count { it.purchased }
            val purchasedValue = list.products.filter { it.purchased }.sumOf { it.total }
            val pendingValue = list.products.filterNot { it.purchased }.sumOf { it.total }
            val progress = if (list.products.isEmpty()) 0f else boughtCount.toFloat() / list.products.size
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFFE6F3EA))) {
                    Column(Modifier.padding(9.dp)) {
                        Text("COMPRADOS", color = Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text(money.format(purchasedValue), color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3DF))) {
                    Column(Modifier.padding(9.dp)) {
                        Text("FALTA COMPRAR", color = Color(0xFF98651B), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text(money.format(pendingValue), color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Green, trackColor = Color(0xFFE5EEE8))
            Spacer(Modifier.height(8.dp))

            // Tabela compacta: todas as colunas cabem na largura disponível, sem rolagem lateral.
            Column(Modifier.weight(1f).fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFFE7E7E7)).border(1.dp, Color.Gray).padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("OK", Modifier.width(34.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Text("Produto", Modifier.weight(0.40f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Text("Qtd", Modifier.weight(0.14f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Text("Preço", Modifier.weight(0.22f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    Text("Total", Modifier.weight(0.24f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                }
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    itemsIndexed(list.products) { index, product ->
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 48.dp)
                                .background(if (index % 2 == 0) Color.White else Color(0xFFF1F1F1))
                                .border(0.5.dp, Color.Gray),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = product.purchased,
                                onCheckedChange = { checked ->
                                    val updated = list.products.toMutableList()
                                    updated[index] = product.copy(purchased = checked)
                                    lists[current] = list.copy(products = updated)
                                    persist()
                                },
                                modifier = Modifier.width(34.dp).padding(start = 0.dp)
                            )
                            Text(
                                product.description,
                                Modifier.weight(0.40f).clickable { editIndex = index; showEditor = true }.padding(end = 2.dp),
                                color = if (product.purchased) Muted else Ink,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(formatQuantity(product.quantity), Modifier.weight(0.14f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            PriceCell(
                                value = product.unitPrice,
                                modifier = Modifier.weight(0.22f),
                                onValue = { newPrice ->
                                    val updated = list.products.toMutableList()
                                    updated[index] = product.copy(unitPrice = newPrice)
                                    lists[current] = list.copy(products = updated)
                                    persist()
                                }
                            )
                            Text(money.format(product.total).replace("R$", "").trim(), Modifier.weight(0.24f), fontWeight = FontWeight.Bold, color = DarkGreen, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Preço total da lista", color = Color.White)
                        Text(money.format(list.total), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Preço atual • itens marcados", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(money.format(purchasedValue), color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        if (deleteProductIndex >= 0 && deleteProductIndex < list.products.size) {
            AlertDialog(
                onDismissRequest = { deleteProductIndex = -1 },
                title = { Text("Excluir produto?") },
                text = { Text("Deseja remover '${list.products[deleteProductIndex].description}' desta lista?") },
                confirmButton = {
                    TextButton(onClick = {
                        val updated = list.products.toMutableList().also { it.removeAt(deleteProductIndex) }
                        lists[current] = list.copy(products = updated)
                        persist()
                        deleteProductIndex = -1
                    }) { Text("Excluir", color = Color(0xFFB64B4B)) }
                },
                dismissButton = { TextButton(onClick = { deleteProductIndex = -1 }) { Text("Cancelar") } }
            )
        }

        if (showEditor) {
            val original = if (editIndex >= 0 && editIndex < list.products.size) list.products[editIndex] else null
            var desc by remember(showEditor, editIndex) { mutableStateOf(original?.description ?: "") }
            var qty by remember(showEditor, editIndex) { mutableStateOf(original?.let { formatQuantity(it.quantity) } ?: "1") }
            var price by remember(showEditor, editIndex) { mutableStateOf(original?.let { String.format(Locale.US, "%.2f", it.unitPrice) } ?: "") }
            var validationError by remember(showEditor, editIndex) { mutableStateOf("") }

            AlertDialog(
                onDismissRequest = { showEditor = false },
                title = { Text(if (editIndex >= 0) "Editar produto" else "Novo produto") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        OutlinedTextField(desc, { desc = it; validationError = "" }, label = { Text("Descrição") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(qty, { qty = it; validationError = "" }, label = { Text("Quantidade") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(price, { price = it; validationError = "" }, label = { Text("Valor unitário (R$) — opcional") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                        if (validationError.isNotBlank()) Text(validationError, color = Color(0xFFB64B4B), style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsedQuantity = qty.trim().replace(",", ".").toDoubleOrNull()
                        val parsedPrice = price.trim().replace(",", ".").toDoubleOrNull()
                        when {
                            desc.isBlank() -> validationError = "Informe a descrição do produto."
                            parsedQuantity == null || parsedQuantity <= 0.0 -> validationError = "Informe uma quantidade válida maior que zero."
                            price.isNotBlank() && (parsedPrice == null || parsedPrice < 0.0) -> validationError = "Informe um valor unitário válido ou deixe em branco."
                            else -> {
                                val updated = list.products.toMutableList()
                                val product = Product(desc.trim(), parsedQuantity, parsedPrice ?: 0.0, original?.purchased ?: false)
                                if (editIndex >= 0 && editIndex < updated.size) updated[editIndex] = product else updated.add(product)
                                lists[current] = list.copy(products = updated)
                                persist()
                                showEditor = false
                            }
                        }
                    }) { Text("Salvar") }
                },
                dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Cancelar") } }
            )
        }
    }
}
